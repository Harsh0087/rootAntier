const PathConstants = {
    HOME: "/",
    TEAM: "/team",
    PORTFOLIO: "/portfolio",
    ABOUT:"/about"
}
export default PathConstants