import React from 'react'
export default function Team() {
  return (
    <div>This is Team.</div>
  )
}