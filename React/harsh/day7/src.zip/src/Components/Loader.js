import React from 'react'

export default function Loader() {
  return (
      <div>
          <h1>Page is loading.</h1>
    </div>
  )
}
