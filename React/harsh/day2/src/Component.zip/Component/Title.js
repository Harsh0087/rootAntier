import React from 'react'

export default function Title(props) {
  return (
      <div>
          <h1>{props.heading}</h1>
      </div>
  )
}
